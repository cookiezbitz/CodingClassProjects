//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class CountPairsRunner
{
	public static void main( String[] args )
	{
		System.out.println( CountPairs.pairCounter("test_cases") );
		//add in all of the provided test cases from the lab handout	
	}
}