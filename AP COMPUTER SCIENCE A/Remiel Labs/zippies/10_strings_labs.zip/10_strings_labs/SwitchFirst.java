//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class SwitchFirst
{
   public static String go( String a, String b )
	{
		return "";
	}
}