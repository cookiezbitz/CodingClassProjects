//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*;

public class MadLibRunner
{
	public static void main( String args[] )
	{
		//make a new MadLib
		MadLib ml = new MadLib("story.txt");
		
		out.println("\n");
	}
}