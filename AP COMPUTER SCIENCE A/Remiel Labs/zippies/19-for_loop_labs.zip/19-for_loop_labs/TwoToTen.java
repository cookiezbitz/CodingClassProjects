//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class TwoToTen
{
	public static long getBaseTen( String bin )
	{
		long ten=0;
		return ten;
	}
}