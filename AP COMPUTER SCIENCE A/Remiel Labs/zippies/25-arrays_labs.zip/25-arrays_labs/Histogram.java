//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.Scanner; 

public class Histogram
{
	private int[] numCount;

	public Histogram(String line, int size )
	{
	}
	
	public int getMax()
	{
		return 0;
	}

	public String toString()
	{
		String output="add code to return the array as a string";
		return output;
	}
}