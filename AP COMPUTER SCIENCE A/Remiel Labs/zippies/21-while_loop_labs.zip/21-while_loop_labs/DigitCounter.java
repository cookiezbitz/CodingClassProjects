//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class DigitCounter
{
   public static int go( int number )
	{
		return 0;
	}
}