//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class StringFirstLetterCheck
{
	public static boolean checkFirstLetter( String wordOne, String wordTwo )
	{
		return false;
	}
}