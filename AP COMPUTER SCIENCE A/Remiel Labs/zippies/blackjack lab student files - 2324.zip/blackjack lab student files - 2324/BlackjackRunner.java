// Class: BlackjackRunner
// Purpose: Runner class used to initiate and play blackjack
// @author TAS
// @version November 2023

import java.util.Scanner;

public class BlackjackRunner
{
    public static void main(String[] args)
    {
        Scanner kb = new Scanner(System.in);
        
        
    }
}