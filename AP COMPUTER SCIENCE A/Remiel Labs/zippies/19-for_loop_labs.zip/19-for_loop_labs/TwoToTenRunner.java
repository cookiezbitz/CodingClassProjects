//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class TwoToTenRunner
{
	public static void main ( String[] args )
	{
		//add test cases			
	}
}