//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class VowelCounterRunner
{
	public static void main ( String[] args )
	{
		System.out.println( VowelCounter.getNumberString("abcdef") );
		//add more test cases		
	}
}


