//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Fibonacci
{
	//instance variable

	//constructors

	//set method

	//get method

	//toString
}