//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class FirstLast
{
   public static String execute( String a, String b )
    {
        return "";
    }
}