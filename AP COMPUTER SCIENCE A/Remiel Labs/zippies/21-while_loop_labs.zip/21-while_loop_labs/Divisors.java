//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Divisors
{
	public static String getDivisors( int number )
	{
		String divisors="";
		return divisors; 
	}
}