//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class Prime
{
	public static boolean isPrime( int num )
	{
		return true;
	}
}