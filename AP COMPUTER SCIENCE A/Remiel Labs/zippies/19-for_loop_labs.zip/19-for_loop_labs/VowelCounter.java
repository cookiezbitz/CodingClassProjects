//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class VowelCounter
{
	public static String getNumberString( String s)
	{
		return "";
	}
}


