//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class StringStuff
{

}