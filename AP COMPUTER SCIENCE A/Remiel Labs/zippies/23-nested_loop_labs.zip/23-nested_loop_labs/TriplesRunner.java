//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*;

public class TriplesRunner
{
   public static void main(String args[])
   {
	}
}