//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Grade
{
	public static String getLetterGrade( int numGrade )
	{
		String letGrade="";
		return letGrade;
	}
}