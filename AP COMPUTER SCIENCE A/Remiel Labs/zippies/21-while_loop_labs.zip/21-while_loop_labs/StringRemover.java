//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

class StringRemover
{
   private String remove;
   private String sentence;

	public StringRemover( String sen, String rem )
	{
	}

	public void removeStrings()
	{
	}

	public String toString()
	{
		return "";
	}
}