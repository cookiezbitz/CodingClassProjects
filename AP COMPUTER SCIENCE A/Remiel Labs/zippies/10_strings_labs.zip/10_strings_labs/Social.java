//(c) A+ Computer Science
//www.apluscompsci.com

public class Social
{

}