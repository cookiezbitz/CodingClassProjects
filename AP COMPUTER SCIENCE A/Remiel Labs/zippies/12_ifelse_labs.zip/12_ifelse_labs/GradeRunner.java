//(c) A+ Computer Science
// www.apluscompsci.com
//Name -

public class GradeRunner
{
	public static void main( String args[] )
	{
		System.out.println( Grade.getLetterGrade( 99 ) );
		//add test cases
	}
}