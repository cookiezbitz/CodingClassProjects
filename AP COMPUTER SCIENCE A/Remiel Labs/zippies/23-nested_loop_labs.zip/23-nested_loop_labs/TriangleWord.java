//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleWord
{
   private String word;

	public TriangleWord(String w)
	{
		word=w;
	}

	public String toString()
	{
		String output="";
		return output+"\n";
	}
}