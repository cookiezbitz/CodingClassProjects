//(c) A+ Computer Science
// www.apluscompsci.com
//Name -  

import java.util.Scanner;
import static java.lang.System.*;

public class GuessingGame
{
	private int upperBound;

	public GuessingGame(int stop)
	{
	}

	public void playGame()
	{
		Scanner keyboard = new Scanner(System.in);
	}

	public String toString()
	{
		String output="";
		return output;
	}
}