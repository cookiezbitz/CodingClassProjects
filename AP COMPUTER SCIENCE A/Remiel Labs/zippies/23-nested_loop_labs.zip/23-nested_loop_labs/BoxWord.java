//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class BoxWord
{
	public static String go( String word )
	{
		String output="";
		return output+"\n";
	}
}