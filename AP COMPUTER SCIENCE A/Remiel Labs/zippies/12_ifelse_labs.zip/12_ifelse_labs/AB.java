//(c) A+ Computer Science
// www.apluscompsci.com
//Name -

public class AB
{
	public static boolean check( String s, String a, String b)
	{
		return false;
	}
}