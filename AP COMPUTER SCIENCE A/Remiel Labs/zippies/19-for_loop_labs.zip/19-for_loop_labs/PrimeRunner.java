//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class PrimeRunner
{
	public static void main ( String[] args )
	{
		//add test cases		
	}	
}