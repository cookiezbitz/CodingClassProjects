//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Decoder
{
	public String deCode( String s )
	{
		String result="";
		return result;
	}
}