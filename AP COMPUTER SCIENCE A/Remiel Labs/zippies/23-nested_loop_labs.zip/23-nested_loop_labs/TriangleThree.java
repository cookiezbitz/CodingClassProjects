//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleThree
{
	public static String go( int size, String let )
	{
		String output="";
		return output+"\n";
	}
}