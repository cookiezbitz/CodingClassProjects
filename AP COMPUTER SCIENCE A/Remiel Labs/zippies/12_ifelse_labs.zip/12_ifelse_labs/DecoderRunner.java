//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class DecoderRunner
{
	public static void main( String args[] )
	{
		//add test cases
	}
}