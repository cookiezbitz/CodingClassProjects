//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class StarsRunner
{
   public static void main(String args[])
   {
      //instantiate a StarsAndStripes object
      
      //call the methods needed to make the patterns on the word document
      
   }
}