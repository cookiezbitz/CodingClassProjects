//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class LeaveOut
{
    //pre : a.length() > 1
    //post : string returned minus character at i
   public static String out( String a, int i)
    {
        return "";
    }
}