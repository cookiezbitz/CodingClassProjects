//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class CoolNumbersRunner
{
	public static void main( String[] args )
	{
		System.out.println( CoolNumbers.countCoolNumbers(250) + " cool numbers between 6 - " + 250);
		//add more test cases
	}
}