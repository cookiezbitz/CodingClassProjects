//(c) A+ Computer Science
//www.apluscompsci.com

import java.util.*;

public class RectRunner
{
	public static void main( String[] args )
	{
		Scanner kb = new Scanner( System.in );
		System.out.print( "Enter the length :: " );
		int length = kb.nextInt();
		System.out.print( "Enter the width :: " );		
		int width = kb.nextInt();
		
		//print your answer here
		
	}
}

/*
 
Sample Data: 
12  5
131 75
20  25
9  256
36  72
8  6
18  16


Sample Output : 
34.0
412.0
90.0
530.0
216.0
28.0
68.0

*/
