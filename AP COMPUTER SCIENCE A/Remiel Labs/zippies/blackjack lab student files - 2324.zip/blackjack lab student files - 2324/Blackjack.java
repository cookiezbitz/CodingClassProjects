// Class: Blackjack
// Purpose: Main class used to play the card game Blackjack
// @author TAS
// @version November 2023

import java.util.Scanner;

public class Blackjack
{
    // deck of cards used for this game

    // arrays to hold the dealer's and player's hands

    // indexes to keep track of cards in players hands
    
    // keep track of win points for player

    // number of rounds that have been played

    // scanner used for keyboard input
    private Scanner kb;

    // constructor
    public Blackjack()
    {
    }

    // "main" method in the class, used to play one complete round of Blackjack
    public void playRound()
    {
    }

    // after a round, clear out the player/dealer hands
    public void resetHands()
    {
    }
    
    // return a nicely formatted string of the cards in a hand
    public String printHand(Card[] cards)
    {
        String out = "";

        return out;
    }

    // look at the current hands and determine a winner, and print it out
    public void checkWinner()
    {
    }

    // calculate the value of a hand (be sure to handle aces correctly!)
    public int getHandValue(Card[] cards)
    {
        int sum = 0;

        return sum;
    }
    
}