//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Quadratic
{
	public static double getRootOne( int a, int b, int c )
	{
		return 0;
	}
	
	public static double getRootTwo( int a, int b, int c )
	{
		return 0;
	}
}