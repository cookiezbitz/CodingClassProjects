//(c) A+ Computer Science
// www.apluscompsci.com
//Name -  

public class PassRunner
{
	public static void main( String args[] )
	{
		PasswordCheck test = new PasswordCheck();
		test.check();
	} 
}