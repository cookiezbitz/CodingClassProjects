//(c) A+ Computer Science
//www.apluscompsci.com
//Name

public class CountPairs
{
	public static int pairCounter( String str )
	{ 
		int count = 0;
		return count;
	}
}