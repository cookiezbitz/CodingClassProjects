//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleWordRunner
{
   public static void main(String args[])
   {	
	}
}