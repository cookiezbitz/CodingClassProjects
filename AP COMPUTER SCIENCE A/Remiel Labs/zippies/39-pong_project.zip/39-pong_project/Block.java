//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.awt.Color;
import java.awt.Graphics;

public class Block {
   private int xPos;
   private int yPos;
   private int width;
   private int height;

   private Color color;

   public Block() {
   }

   // add other Block constructors - x , y , width, height, color

   // add the other set methods

   public void setColor(Color col) {

   }

   public void draw(Graphics window) {
      window.setColor(color);
      window.fillRect(xPos, yPos, width, height);
   }

   public void draw(Graphics window, Color col) {
      window.setColor(col);
      window.fillRect(xPos, yPos, width, height);
   }

   public boolean equals(Object obj) {
      return false;
   }

   // add the other get methods

   // add a toString() method - x , y , width, height, color
}