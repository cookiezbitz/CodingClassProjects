//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
 
public class Triples
{
   private int number;

	public Triples(int num)
	{
	}
	
	private int greatestCommonFactor(int a, int b, int c)
	{
		return 1;
	}

	public String toString()
	{
		String output="";
		return output+"\n";
	}
}