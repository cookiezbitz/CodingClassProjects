//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleThreeRunner
{
   public static void main( String args[] )
   {
   }
}