//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*;

public class StringFirstLetterRunner
{
	public static void main( String args[] )
	{
		out.println(StringFirstLetterCheck.checkFirstLetter( "hello","howdy" ));
		out.println(StringFirstLetterCheck.checkFirstLetter( "three","two" ));
		out.println(StringFirstLetterCheck.checkFirstLetter( "TCEA","UIL" ));
	}
}