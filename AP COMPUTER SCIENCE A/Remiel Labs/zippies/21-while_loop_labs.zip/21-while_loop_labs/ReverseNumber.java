//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class ReverseNumber
{
	public static int getReverse( int number )
	{
		int rev=0;		
		return rev;
	}	
}