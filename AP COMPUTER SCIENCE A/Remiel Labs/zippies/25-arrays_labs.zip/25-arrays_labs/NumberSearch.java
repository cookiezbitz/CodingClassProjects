//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class NumberSearch
{
	public static int getNextLargest(int[] numArray, int searchNum)
	{
		return -1;
	}
}