//(c) A+ Computer Science
//www.apluscompsci.com

public class DogRunner
{
	public static void main( String[] args )
	{
		//add test cases	
		//use the examples on the lab handout			
	}
}