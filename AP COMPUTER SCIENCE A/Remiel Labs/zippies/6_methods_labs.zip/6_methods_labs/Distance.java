//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class Distance
{
	public static double getDistance(int xOne, int yOne, int xTwo, int yTwo )
	{
		return 0;	
	}
}