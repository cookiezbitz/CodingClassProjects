//(c) A+ Computer Science
//www.apluscompsci.com
//Name - 

public class NumChecker
{
	public static int check( int x )
	{
		return 0;
	}
}