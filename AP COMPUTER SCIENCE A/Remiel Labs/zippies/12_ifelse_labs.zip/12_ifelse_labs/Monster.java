//(c) A+ Computer Science
//www.apluscompsci.com
//Name - 

public class Monster
{
	private String name;
	private int howBig;	

	public Monster(String n, int size)
	{
	}

	public String getName()
	{
		return "";
	}
	
	public int getHowBig()
	{
		return 0;
	}
	
	public boolean isBigger(Monster other)
	{
		return false;
	}
	
	public boolean isSmaller(Monster other)
	{
		//call isBigger() use !
		return false;
	}

	public boolean namesTheSame(Monster other)
	{
		return false;
	}
	
	public String toString()
	{
		return "";
	}
}