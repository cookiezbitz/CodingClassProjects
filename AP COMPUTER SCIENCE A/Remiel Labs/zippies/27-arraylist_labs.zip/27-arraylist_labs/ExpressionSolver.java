//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.util.ArrayList;
import java.util.Scanner;
import static java.lang.Integer.*;
import static java.lang.System.*;

public class ExpressionSolver
{
	//add in instance variables

	public ExpressionSolver(String s)
	{
	}

	public void setExpression(String s)
	{
	}

	public void solveExpression()
	{
	}

	public String toString( )
	{
		return "";
	}
}