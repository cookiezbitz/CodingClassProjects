//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleFive
{
	public static String go( int amount, char letter )
	{
		String output="";
		return output;
	}
}