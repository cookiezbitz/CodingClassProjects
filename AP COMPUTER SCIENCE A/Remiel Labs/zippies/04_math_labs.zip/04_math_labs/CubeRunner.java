//(c) A+ Computer Science
//www.apluscompsci.com

import java.util.*;

public class CubeRunner
{
	public static void main( String[] args )
	{
		Scanner kb = new Scanner( System.in );
		System.out.print( "Enter the side :: " );
		int side = kb.nextInt();

		//print your answer here
	}
}

/*
 
Sample Data: 
112
4
33
50
5
19
111



Sample Output : 
Cube area is :: 75264.0
Cube area is :: 96.0
Cube area is :: 6534.0
Cube area is :: 15000.0
Cube area is :: 150.0
Cube area is :: 2166.0
Cube area is :: 73926.0



*/
