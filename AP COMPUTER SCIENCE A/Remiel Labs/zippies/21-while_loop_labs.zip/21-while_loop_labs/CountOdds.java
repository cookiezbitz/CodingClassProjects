//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class CountOdds
{
   public static int go( int number )
	{
		return 0;
	}
}